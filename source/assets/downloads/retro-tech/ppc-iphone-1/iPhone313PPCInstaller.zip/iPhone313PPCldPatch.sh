#!/bin/bash

# --- Post-Install Script: Fixes Intel-only ld after SDK install ---

# Define constants
APP_NAME="iPhone OS 3.1.3 PPC Enabler LD Patch"

# Paths
TARGET_LD="/Developer/Platforms/iPhoneOS.platform/Developer/usr/bin/ld"
SOURCE_PPC_LD="/Developer/usr/bin/ld"
BACKUP_INTEL_LD="${TARGET_LD}.backup.intel"


# 1. PRECONDITION: Check for root privileges
if [ "$(id -u)" != "0" ]; then
   echo "ERROR: This script must be run as root (using sudo)." >&2
   exit 1
fi

# 2. PRECONDITION: Check if backup file already exists
if [ -f "$BACKUP_INTEL_LD" ]; then
   echo "ERROR: Backup file already exists at $BACKUP_INTEL_LD." >&2
   echo "The linker swap appears to have been performed previously. Halting." >&2
   exit 1
fi

echo "--- $APP_NAME Post-Install Script Started ---"

# 3. Check for required files
if [ -f "$TARGET_LD" ] && [ -f "$SOURCE_PPC_LD" ]; then
    echo "Verifying files: SUCCESS."
    echo "Target linker ($TARGET_LD) and source linker ($SOURCE_PPC_LD) found."

    # 4. Backup the newly installed (Intel) 'ld' binary
    echo "COMMAND: Backing up Intel 'ld' binary to $BACKUP_INTEL_LD"
    cp "$TARGET_LD" "$BACKUP_INTEL_LD"
    
    if [ $? -ne 0 ]; then
        echo "ERROR: Failed to create backup. Halting." >&2
        exit 1
    fi

    # 5. Copy the functional PPC 'ld' over the Intel one
    echo "COMMAND: Copying functional PPC 'ld' over the Intel one..."
    cp "$SOURCE_PPC_LD" "$TARGET_LD"
    
    if [ $? -eq 0 ]; then
        # Ensure the file has the correct permissions after copy
        echo "COMMAND: Setting executable permissions for $TARGET_LD"
        chmod 755 "$TARGET_LD"
        echo "SUCCESS: PPC 'ld' copied and permissions set."
    else
        echo "ERROR: Failed to copy PPC 'ld'. Halting installation." >&2
        exit 1 
    fi

else
    # 6. If the target or source file is NOT found
    echo "FATAL ERROR: Required files were not found." >&2
    echo "Target exists: $([ -f "$TARGET_LD" ] && echo "Yes" || echo "No"). Source exists: $([ -f "$SOURCE_PPC_LD" ] && echo "Yes" || echo "No")." >&2
    exit 1 
fi

echo "--- $APP_NAME Post-Install Script Completed Successfully ---"
exit 0